package eMarket.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import eMarket.EMarketApp;
import eMarket.domain.Order;
import eMarket.domain.Product;
import net.bytebuddy.dynamic.DynamicType.Builder.FieldDefinition.Optional;

@Controller
public class OrderController {

	@RequestMapping("/order")
    public String toOrderview (Model model) {
		model.addAttribute("orderList", EMarketApp.getStore().getOrderList());	
    return "form/orderMaster";
    }	


  //Add to the Order
  @RequestMapping (value = "order/add", method = RequestMethod.GET)
  public String addgetOrder (@ModelAttribute Order order, Model model ) {
	  order.setId();
	  EMarketApp.getStore().getOrderList().add(order);
		   model.addAttribute("orderList", EMarketApp.getStore().getOrderList());
  return "form/orderDetail";
} 	

  //Delete Order
  @RequestMapping (value = "order/delete", method = RequestMethod.GET)
  public String deleteOrder(@RequestParam(value="orderId", required=false, defaultValue="-1") int orderId, Model model){
	EMarketApp.getStore().getOrderList().removeIf(p -> (p.getId() == orderId));
		 model.addAttribute("orderList", EMarketApp.getStore().getOrderList());
  return "form/orderMaster";
}	
 
}
