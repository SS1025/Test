/**
 * (C) Artur Boronat, 2015
 */
package eMarket.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import eMarket.EMarketApp;
import eMarket.domain.Product;
@Controller
public class ItemController {
	@RequestMapping("item/Detail")
    public String toItemview (Model model) {
		model.addAttribute("itemFormDto", EMarketApp.getStore().getProductList());	
    return "form/itemDetail";
    }
	
    @RequestMapping(value = "/itemDetail", method = RequestMethod.GET)
    public String productDetail(@ModelAttribute("product") Product product, BindingResult result, @RequestParam(value="productId", required=false, defaultValue="-1") int productId, Model model) {
		if (productId >= 0) {
    		// modify
    		Product p2 = EMarketApp.getStore().getProductList().stream().filter(p -> (((Product) p).getId() == productId)).findAny().get();
    		product.setId(p2.getId());
    		product.setName(p2.getName());
    		product.setDescription(p2.getDescription());
    		product.setPrice(p2.getPrice());
    	} else {
    		// add
    		product.setId();
    	}	
		return "form/itemDetail";
    }    
}
