report {
	enabled true
	logFileDir 'build/spock-reports/'
	logFileName 'spock-report.json'
	logFileSuffix new Date().format('yyyy-MM-dd_HH_mm_ss')
}
